import Home from '../../src/old_pages_backup/Home'

export const metadata = {
  title: 'Home - Shame to Flame',
}

export default function Page() {
  return <Home />
}
