import PrayerRockStory from '../../src/old_pages_backup/PrayerRockStory'

export const metadata = {
  title: 'PrayerRockStory - Shame to Flame',
}

export default function Page() {
  return <PrayerRockStory />
}
