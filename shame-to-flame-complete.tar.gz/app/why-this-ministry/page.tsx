import WhyThisMinistry from '../../src/old_pages_backup/WhyThisMinistry'

export const metadata = {
  title: 'WhyThisMinistry - - Shame to Flame',
}

export default function Page() {
  return <WhyThisMinistry />
}
