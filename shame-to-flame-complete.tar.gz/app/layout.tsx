import type { Metadata } from 'next'
import './globals.css'
import Navigation from '../src/components/Navigation'
import Footer from '../src/components/Footer'
import VideoBackground from '../src/components/VideoBackground'

export const metadata: Metadata = {
  title: 'Shame to Flame - From Darkness to Light',
  description: 'A Christian ministry guiding you from shame, guilt, and grief toward renewed hope, faith, and purpose through God\'s love and grace.',
  icons: {
    icon: '/flame-icon.svg',
    apple: '/flame-icon.svg',
  },
  manifest: '/manifest.json',
  openGraph: {
    type: 'website',
    title: 'Shame to Flame - From Darkness to Light',
    description: 'A Christian ministry guiding you from shame, guilt, and grief toward renewed hope, faith, and purpose through God\'s love and grace.',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;1,400&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet" />
      </head>
      <body>
        <VideoBackground />
        <Navigation />
        <main>{children}</main>
        <Footer />
        <script
          dangerouslySetInnerHTML={{
            __html: `
              if ('serviceWorker' in navigator) {
                window.addEventListener('load', () => {
                  navigator.serviceWorker.register('/sw.js')
                    .then((registration) => {
                      console.log('SW registered: ', registration);
                    })
                    .catch((registrationError) => {
                      console.log('SW registration failed: ', registrationError);
                    });
                });
              }
            `,
          }}
        />
      </body>
    </html>
  )
}
