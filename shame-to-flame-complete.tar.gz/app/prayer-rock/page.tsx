import PrayerRock from '../../src/old_pages_backup/PrayerRock'

export const metadata = {
  title: 'PrayerRock - Shame to Flame',
}

export default function Page() {
  return <PrayerRock />
}
