import MinistryHub from '../../src/old_pages_backup/MinistryHub'

export const metadata = {
  title: 'Ministry -Hub - Shame to Flame',
}

export default function Page() {
  return <MinistryHub />
}
