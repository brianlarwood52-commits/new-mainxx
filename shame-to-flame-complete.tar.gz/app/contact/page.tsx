import Contact from '../../src/old_pages_backup/Contact'

export const metadata = {
  title: 'Contact - Shame to Flame',
}

export default function Page() {
  return <Contact />
}
