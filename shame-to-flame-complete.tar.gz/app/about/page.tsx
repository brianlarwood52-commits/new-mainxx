import About from '../../src/old_pages_backup/About'

export const metadata = {
  title: 'About - Shame to Flame',
}

export default function Page() {
  return <About />
}
