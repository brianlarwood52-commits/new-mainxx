import HealingPathways from '../../src/old_pages_backup/HealingPathways'

export const metadata = {
  title: 'HealingPathways - Shame to Flame',
}

export default function Page() {
  return <HealingPathways />
}
