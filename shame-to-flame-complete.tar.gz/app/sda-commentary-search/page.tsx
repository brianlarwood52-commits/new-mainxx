import SDACommentarySearch from '../../src/old_pages_backup/SDACommentarySearch'

export const metadata = {
  title: 'SDACommentarySearch - Shame to Flame',
}

export default function Page() {
  return <SDACommentarySearch />
}
