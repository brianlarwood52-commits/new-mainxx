import DailyFire from '../../src/old_pages_backup/DailyFire'

export const metadata = {
  title: 'DailyFire - Shame to Flame',
}

export default function Page() {
  return <DailyFire />
}
