import BibleStudy from '../../src/old_pages_backup/BibleStudy'

export const metadata = {
  title: 'BibleStudy - Shame to Flame',
}

export default function Page() {
  return <BibleStudy />
}
