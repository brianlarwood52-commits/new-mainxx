import MaryMagdaleneApologetic from '../../src/old_pages_backup/MaryMagdaleneApologetic'

export const metadata = {
  title: 'MaryMagdalene -Apologetic - Shame to Flame',
}

export default function Page() {
  return <MaryMagdaleneApologetic />
}
