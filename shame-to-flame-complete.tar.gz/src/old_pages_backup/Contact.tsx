'use client'

import React, { useState } from 'react';
import { Mail, Phone, Heart, Send, CheckCircle, AlertCircle, ExternalLink } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    requestType: 'general'
  });

  const [showSuccess, setShowSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Create email content
    const emailSubject = formData.subject || `${formData.requestType} - Contact Form Message`;
    const emailBody = `
Name: ${formData.name}
Email: ${formData.email}
Request Type: ${formData.requestType}
Subject: ${formData.subject}

Message:
${formData.message}

---
Sent from Shame to Flame Contact Form
    `.trim();

    // Method 1: Try using a simple form submission to a working endpoint
    try {
      const response = await fetch('https://formsubmit.co/miamics@hotmail.com', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          subject: emailSubject,
          message: formData.message,
          requestType: formData.requestType,
          _subject: `New message from ${formData.name} - Shame to Flame`,
          _captcha: 'false',
          _template: 'table'
        })
      });

      if (response.ok) {
        setShowSuccess(true);
        setFormData({
          name: '',
          email: '',
          subject: '',
          message: '',
          requestType: 'general'
        });
      } else {
        throw new Error('Form submission failed');
      }
    } catch (error) {
      console.error('Form submission error:', error);
      // Fallback to mailto link
      openMailtoLink(emailSubject, emailBody);
    }

    setIsSubmitting(false);
  };

  const openMailtoLink = (subject: string, body: string) => {
    const mailtoLink = `mailto:miamics@hotmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(mailtoLink, '_blank');
    setShowSuccess(true);
  };

  const handleDirectEmail = () => {
    const emailSubject = formData.subject || `${formData.requestType} - Contact Form Message`;
    const emailBody = `
Name: ${formData.name}
Email: ${formData.email}
Request Type: ${formData.requestType}
Subject: ${formData.subject}

Message:
${formData.message}

---
Sent from Shame to Flame Contact Form
    `.trim();

    openMailtoLink(emailSubject, emailBody);
  };

  return (
    <div className="animate-fade-in">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-sky-50 to-flame-50 dark:from-sky-900/30 dark:to-flame-900/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Heart className="h-16 w-16 text-flame-500 mx-auto mb-6" />
          <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-800 dark:text-white mb-6">
            We're Here for You
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 leading-relaxed max-w-3xl mx-auto">
            Your journey toward healing doesn't have to be walked alone. Whether you need prayer, 
            guidance, or just someone to listen, we're here to support you.
          </p>
        </div>
      </section>

      {/* Contact Options */}
      <section className="py-16 bg-white dark:bg-gray-900">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div className="text-center bg-sky-50 dark:bg-sky-900/30 rounded-xl p-6">
              <Mail className="h-12 w-12 text-sky-600 dark:text-sky-400 mx-auto mb-4" />
              <h3 className="font-serif text-xl font-semibold text-gray-800 dark:text-white mb-2">Email Support</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">Reach out for personal support, prayer requests, or questions about healing resources.</p>
              <a href="mailto:miamics@hotmail.com" className="text-sky-600 dark:text-sky-400 hover:text-sky-700 dark:hover:text-sky-300 font-medium">
                miamics@hotmail.com
              </a>
            </div>
            
            <div className="text-center bg-flame-50 dark:bg-flame-900/30 rounded-xl p-6">
              <Phone className="h-12 w-12 text-flame-600 dark:text-flame-400 mx-auto mb-4" />
              <h3 className="font-serif text-xl font-semibold text-gray-800 dark:text-white mb-2">Prayer Line</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">Call our prayer line for immediate support and encouragement from trained prayer partners.</p>
              <span className="text-flame-600 dark:text-flame-400 font-medium">1-800-HOPE-NOW</span>
            </div>
            
            <div className="text-center bg-sage-50 dark:bg-sage-900/30 rounded-xl p-6">
              <Heart className="h-12 w-12 text-sage-600 dark:text-sage-400 mx-auto mb-4" />
              <h3 className="font-serif text-xl font-semibold text-gray-800 dark:text-white mb-2">Crisis Support</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">If you're in crisis, please reach out immediately. We can connect you with local resources.</p>
              <span className="text-sage-600 dark:text-sage-400 font-medium">24/7 Crisis Line</span>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-16 bg-gradient-to-r from-sky-50 to-flame-50 dark:from-sky-900/30 dark:to-flame-900/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8">
            <h2 className="font-serif text-3xl font-bold text-gray-800 dark:text-white mb-6 text-center">
              Send Us a Message
            </h2>
            <p className="text-gray-600 dark:text-gray-300 text-center mb-8">
              We read every message personally and respond with care. Your story matters to us.
            </p>
            
            {showSuccess ? (
              <div className="text-center py-12">
                <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-green-600 dark:text-green-400 mb-2">
                  Message Prepared Successfully!
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6">
                  Your email client should have opened with your message ready to send to miamics@hotmail.com.
                  If it didn't open automatically, you can copy the email address and send manually.
                </p>
                <div className="space-y-4">
                  <button
                    onClick={() => setShowSuccess(false)}
                    className="bg-flame-600 hover:bg-flame-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200 mr-4"
                  >
                    Send Another Message
                  </button>
                  <a
                    href="mailto:miamics@hotmail.com"
                    className="inline-flex items-center bg-sky-600 hover:bg-sky-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200"
                  >
                    Open Email Client
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </a>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Your Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-flame-500 focus:border-transparent transition-all duration-200 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="How would you like us to address you?"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-flame-500 focus:border-transparent transition-all duration-200 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="your.email@example.com"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="requestType" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    How Can We Help?
                  </label>
                  <select
                    id="requestType"
                    name="requestType"
                    value={formData.requestType}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-flame-500 focus:border-transparent transition-all duration-200 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="general">General Questions</option>
                    <option value="prayer">Prayer Request</option>
                    <option value="healing">Healing Resources</option>
                    <option value="testimony">Share Your Testimony</option>
                    <option value="crisis">Crisis Support</option>
                    <option value="ministry">Ministry Partnership</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-flame-500 focus:border-transparent transition-all duration-200 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Brief description of your message"
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Your Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-flame-500 focus:border-transparent transition-all duration-200 bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none"
                    placeholder="Share your heart with us. We're here to listen and support you."
                  ></textarea>
                </div>
                
                <div className="bg-sky-50 dark:bg-sky-900/30 rounded-lg p-4">
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    <strong>How this works:</strong> When you click "Send Message", we'll try to send it directly. 
                    If that doesn't work, your email client will open with the message pre-filled and ready to send to miamics@hotmail.com.
                  </p>
                </div>
                
                <div className="text-center space-y-4">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="inline-flex items-center px-8 py-4 bg-flame-600 hover:bg-flame-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white font-medium rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                        Sending Message...
                      </>
                    ) : (
                      <>
                        Send Message to miamics@hotmail.com
                        <Send className="ml-2 h-5 w-5" />
                      </>
                    )}
                  </button>
                  
                  <div className="text-center">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">Or send directly:</p>
                    <button
                      type="button"
                      onClick={handleDirectEmail}
                      className="inline-flex items-center px-6 py-3 bg-sky-600 hover:bg-sky-700 text-white font-medium rounded-lg transition-all duration-300"
                    >
                      Open Email Client
                      <ExternalLink className="ml-2 h-4 w-4" />
                    </button>
                  </div>
                </div>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* Emergency Resources */}
      <section className="py-16 bg-red-50 dark:bg-red-900/20 border-t-4 border-red-200 dark:border-red-700">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="font-serif text-2xl font-bold text-red-800 dark:text-red-300 mb-6 text-center">
            Immediate Help Available
          </h2>
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
            <p className="text-gray-700 dark:text-gray-200 mb-4 text-center">
              If you're having thoughts of self-harm or suicide, please reach out for immediate help:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-center">
              <div>
                <p className="font-semibold text-gray-800 dark:text-white">National Suicide Prevention Lifeline</p>
                <p className="text-xl font-bold text-red-600 dark:text-red-400">988</p>
              </div>
              <div>
                <p className="font-semibold text-gray-800 dark:text-white">Crisis Text Line</p>
                <p className="text-xl font-bold text-red-600 dark:text-red-400">Text HOME to 741741</p>
              </div>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300 mt-4 text-center">
              These resources are available 24/7 and provide immediate, professional support.
            </p>
          </div>
        </div>
      </section>

      {/* Response Promise */}
      <section className="py-16 bg-gray-900 dark:bg-black text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl font-bold mb-6">
            Our Promise to You
          </h2>
          <p className="text-xl text-gray-300 mb-8 leading-relaxed">
            Every message we receive is precious to us. We typically respond within 24-48 hours, 
            and we always respond with care, respect, and confidentiality.
          </p>
          <p className="text-lg text-flame-300 dark:text-flame-400 italic">
            "You are not alone in your journey. We're honored to walk alongside you toward healing and hope."
          </p>
        </div>
      </section>
    </div>
  );
};

export default Contact;