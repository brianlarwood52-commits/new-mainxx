'use client'

import React from 'react';
import { ExternalLink, Heart, Book, Users, ArrowRight, Globe } from 'lucide-react';

const MinistryHub = () => {
  const ministries = [
    {
      name: "Learn Live Forgive",
      description: "A comprehensive resource for understanding and practicing biblical forgiveness in all areas of life.",
      focus: "Forgiveness Education & Training",
      website: "learnliveforgive.org",
      logo: null,
      features: [
        "Interactive forgiveness workshops",
        "Biblical forgiveness curriculum",
        "Personal forgiveness coaching",
        "Community support groups"
      ],
      color: "sky",
      icon: Heart
    },
    {
      name: "Running to God",
      description: "Supporting those who have experienced spiritual abuse and are seeking to rebuild their relationship with God.",
      focus: "Spiritual Abuse Recovery",
      website: "runningtogod.org",
      logo: "/running-to-god-logo.jpg",
      features: [
        "Spiritual abuse recovery programs",
        "Healthy theology resources",
        "Trauma-informed counseling",
        "Safe community spaces"
      ],
      color: "sage",
      icon: Users
    },
    {
      name: "Project Reconcile",
      description: "Bridging divides and healing relationships through biblical reconciliation principles.",
      focus: "Relationship Restoration",
      website: "projectreconcile.org",
      logo: "/project-reconcile-card-logo7.jpg",
      features: [
        "Conflict resolution training",
        "Marriage restoration support",
        "Family healing programs",
        "Community mediation services"
      ],
      color: "purple",
      icon: Book
    }
  ];

  const partnerships = [
    {
      organization: "National Suicide Prevention Lifeline",
      description: "24/7 crisis support for those in immediate danger",
      contact: "988",
      type: "Crisis Support"
    },
    {
      organization: "American Counseling Association",
      description: "Professional counseling resources and referrals",
      contact: "counseling.org",
      type: "Professional Support"
    },
    {
      organization: "SAMHSA National Helpline",
      description: "Substance abuse and mental health services",
      contact: "1-800-662-4357",
      type: "Mental Health"
    }
  ];

  const getColorClasses = (color: string) => {
    const colorMap: { [key: string]: string } = {
      sky: "from-sky-400 to-sky-600 border-sky-200",
      sage: "from-sage-400 to-sage-600 border-sage-200",
      purple: "from-purple-400 to-purple-600 border-purple-200"
    };
    return colorMap[color] || colorMap.sky;
  };

  return (
    <div className="animate-fade-in">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-sky-50 to-flame-50 dark:from-sky-900/30 dark:to-flame-900/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Globe className="h-16 w-16 text-flame-500 mx-auto mb-6" />
          <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-800 dark:text-white mb-6">
            Ministry Hub
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 leading-relaxed max-w-3xl mx-auto">
            A network of healing ministries working together to address different 
            aspects of spiritual, emotional, and relational restoration. Together, 
            we're stronger in our mission to bring hope and healing.
          </p>
        </div>
      </section>

      {/* Partner Ministries */}
      <section className="py-16 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-gray-800 dark:text-white mb-12 text-center">
            Our Partner Ministries
          </h2>
          
          <div className="space-y-12">
            {ministries.map((ministry, index) => (
              <div key={index} className="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300">
                <div className="flex flex-col lg:flex-row">
                  <div className={`lg:w-1/3 h-48 lg:h-auto ${
                    ministry.logo 
                      ? ministry.name === "Project Reconcile" 
                        ? 'bg-black' 
                        : 'bg-white dark:bg-gray-100' 
                      : `bg-gradient-to-br ${getColorClasses(ministry.color)}`
                  } flex items-center justify-center ${ministry.name === "Project Reconcile" ? 'p-0' : 'p-6'}`}>
                    {ministry.logo ? (
                      <img 
                        src={ministry.logo} 
                        alt={`${ministry.name} logo`}
                        className="max-w-full max-h-full object-contain"
                      />
                    ) : (
                      <ministry.icon className="h-16 w-16 text-white" />
                    )}
                  </div>
                  
                  <div className="lg:w-2/3 p-8">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-serif text-2xl font-bold text-gray-800 dark:text-white">{ministry.name}</h3>
                      <a 
                        href={`https://${ministry.website}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center text-flame-600 dark:text-flame-400 hover:text-flame-700 dark:hover:text-flame-300 font-medium"
                      >
                        Visit Site
                        <ExternalLink className="ml-1 h-4 w-4" />
                      </a>
                    </div>
                    
                    <div className="mb-4">
                      <span className="inline-block bg-flame-100 dark:bg-flame-900/30 text-flame-700 dark:text-flame-300 text-sm font-medium px-3 py-1 rounded-full">
                        {ministry.focus}
                      </span>
                    </div>
                    
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6">{ministry.description}</p>
                    
                    <div>
                      <h4 className="font-semibold text-gray-800 dark:text-white mb-3">Key Features:</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {ministry.features.map((feature, idx) => (
                          <div key={idx} className="flex items-center">
                            <span className="w-2 h-2 bg-flame-400 rounded-full mr-3"></span>
                            <span className="text-gray-600 dark:text-gray-300">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How We Work Together */}
      <section className="py-16 bg-gradient-to-r from-sky-50 to-flame-50 dark:from-sky-900/30 dark:to-flame-900/30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-gray-800 dark:text-white mb-12 text-center">
            How We Work Together
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg text-center">
              <div className="w-12 h-12 bg-sky-100 dark:bg-sky-900/50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-6 w-6 text-sky-600 dark:text-sky-400" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-gray-800 dark:text-white mb-3">Shared Resources</h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                We share educational materials, training programs, and best practices to ensure 
                comprehensive care for those we serve.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg text-center">
              <div className="w-12 h-12 bg-flame-100 dark:bg-flame-900/50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="h-6 w-6 text-flame-600 dark:text-flame-400" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-gray-800 dark:text-white mb-3">Referral Network</h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                When someone needs specialized support, we connect them with the ministry 
                best equipped to help their specific situation.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg text-center">
              <div className="w-12 h-12 bg-sage-100 dark:bg-sage-900/50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Book className="h-6 w-6 text-sage-600 dark:text-sage-400" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-gray-800 dark:text-white mb-3">Collaborative Training</h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                Our teams train together to ensure consistent, trauma-informed approaches 
                across all our ministries.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Professional Partnerships */}
      <section className="py-16 bg-white dark:bg-gray-900">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-gray-800 dark:text-white mb-12 text-center">
            Professional Partnerships
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {partnerships.map((partner, index) => (
              <div key={index} className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
                <div className="mb-4">
                  <span className="inline-block bg-flame-100 dark:bg-flame-900/30 text-flame-700 dark:text-flame-300 text-xs font-medium px-3 py-1 rounded-full">
                    {partner.type}
                  </span>
                </div>
                
                <h3 className="font-serif text-lg font-semibold text-gray-800 dark:text-white mb-3">
                  {partner.organization}
                </h3>
                
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-4">{partner.description}</p>
                
                <div className="text-flame-600 dark:text-flame-400 font-medium">
                  Contact: {partner.contact}
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-12 bg-yellow-50 dark:bg-yellow-900/20 rounded-xl p-6 border-l-4 border-yellow-400 dark:border-yellow-600">
            <h3 className="font-semibold text-yellow-800 dark:text-yellow-300 mb-2">Important Note</h3>
            <p className="text-yellow-700 dark:text-yellow-300">
              While our ministries provide spiritual and emotional support, we recognize that some 
              situations require professional medical or psychological intervention. We maintain 
              partnerships with licensed professionals to ensure comprehensive care.
            </p>
          </div>
        </div>
      </section>

      {/* Join Our Network */}
      <section className="py-16 bg-gradient-to-br from-sky-50 to-flame-50 dark:from-sky-900/30 dark:to-flame-900/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8">
            <div className="text-center mb-8">
              <Globe className="h-12 w-12 text-flame-500 mx-auto mb-4" />
              <h2 className="font-serif text-3xl font-bold text-gray-800 dark:text-white mb-4">
                Join Our Ministry Network
              </h2>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                Are you leading a ministry focused on healing, restoration, or spiritual growth? 
                We'd love to explore how we might work together to serve those in need.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="font-serif text-xl font-semibold text-gray-800 dark:text-white mb-4">Partnership Criteria</h3>
                <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-flame-400 rounded-full mr-3"></span>
                    Biblical foundation and Christ-centered approach
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-flame-400 rounded-full mr-3"></span>
                    Trauma-informed care practices
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-flame-400 rounded-full mr-3"></span>
                    Commitment to safety and confidentiality
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-flame-400 rounded-full mr-3"></span>
                    Professional accountability and oversight
                  </li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-serif text-xl font-semibold text-gray-800 dark:text-white mb-4">Partnership Benefits</h3>
                <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-sky-400 rounded-full mr-3"></span>
                    Shared resources and training materials
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-sky-400 rounded-full mr-3"></span>
                    Cross-referral opportunities
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-sky-400 rounded-full mr-3"></span>
                    Collaborative training programs
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-sky-400 rounded-full mr-3"></span>
                    Increased reach and impact
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="text-center mt-8">
              <button className="inline-flex items-center px-8 py-4 bg-flame-600 hover:bg-flame-700 text-white font-medium rounded-full transition-all duration-300 transform hover:scale-105">
                Apply for Partnership
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Together */}
      <section className="py-16 bg-gray-900 dark:bg-black text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="font-serif text-3xl md:text-4xl font-bold mb-12 text-center">
            Our Collective Impact
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center mb-12">
            <div>
              <div className="text-4xl font-bold text-flame-400 mb-2">2,500+</div>
              <p className="text-gray-300">Lives Touched</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-sky-400 mb-2">150+</div>
              <p className="text-gray-300">Healing Programs</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-sage-400 mb-2">50+</div>
              <p className="text-gray-300">Trained Counselors</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">24/7</div>
              <p className="text-gray-300">Support Available</p>
            </div>
          </div>
          
          <div className="text-center">
            <p className="text-xl text-gray-300 leading-relaxed max-w-3xl mx-auto">
              When ministries unite with a common purpose, the impact multiplies exponentially. 
              Together, we're creating a comprehensive network of hope, healing, and restoration 
              that reaches into every corner of human brokenness with God's transformative love.
            </p>
          </div>
        </div>
      </section>

      {/* Scripture Foundation */}
      <section className="py-16 bg-gradient-to-br from-sky-50 to-flame-50 dark:from-sky-900/30 dark:to-flame-900/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Book className="h-12 w-12 text-sky-600 dark:text-sky-400 mx-auto mb-6" />
          <h2 className="font-serif text-3xl font-bold text-gray-800 dark:text-white mb-8">
            United in Purpose
          </h2>
          
          <blockquote className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
            <p className="font-serif text-xl text-gray-700 dark:text-gray-200 italic mb-3">
              "As iron sharpens iron, so one person sharpens another... Though one may be overpowered, 
              two can defend themselves. A cord of three strands is not quickly broken."
            </p>
            <cite className="text-flame-600 dark:text-flame-400 font-medium">Proverbs 27:17, Ecclesiastes 4:12</cite>
          </blockquote>
        </div>
      </section>
    </div>
  );
};

export default MinistryHub;